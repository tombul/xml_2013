package fu.berlin.de.webdatabrowser.util;

public interface HttpResponseHandler {
    public void onHttpResultAvailable(String source);
}
