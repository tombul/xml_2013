/** Automatically generated file. DO NOT MODIFY */
package fu.berlin.de.webdatabrowser;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}